#include <WiFi.h>

#include <AsyncTCP.h>

#include <ESPAsyncWebServer.h>

#include <ArduinoJson.h>

#include <OneWire.h>

#include <DallasTemperature.h>



// --- 1. CONFIGURAÇÕES ---

const char* ssid = "Graest-TI";

const char* password = "!gra.3st#";



// --- 2. CONFIGURAÇÕES DO SENSOR DS18B20 ---

const int pinoSensor = 4; // Fio de dados do sensor no GPIO 4

OneWire oneWire(pinoSensor);

DallasTemperature sensorTemp(&oneWire);



// --- 3. VARIÁVEIS GLOBAIS ---

float currentTemp = 0.0;

String systemStatus = "INICIANDO...";

unsigned long lastUpdate = 0;



AsyncWebServer server(80);



// --- 4. FRONTEND (A INTERFACE NOVA E LITERAL) ---

const char index_html[] PROGMEM = R"rawliteral(

<!DOCTYPE html>

<html lang="pt-br">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>MONITORAMENTO DE MOTOR - ESP32</title>

    <style>

        @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap');

       

        :root {

            --neon-blue: #00f2ff;

            --neon-purple: #bd00ff;

            --bg-dark: #02040a;

            --panel-bg: rgba(0, 10, 20, 0.75);

            --grid-color: rgba(0, 242, 255, 0.05);

        }



        body {

            background-color: var(--bg-dark);

            color: var(--neon-blue);

            font-family: 'Share Tech Mono', monospace;

            margin: 0;

            height: 100vh;

            display: flex;

            flex-direction: column;

            align-items: center;

            justify-content: center;

            overflow: hidden;

            background-image:

                linear-gradient(var(--grid-color) 1px, transparent 1px),

                linear-gradient(90deg, var(--grid-color) 1px, transparent 1px);

            background-size: 20px 20px;

        }



        .dashboard {

            width: 95%; max-width: 1200px; height: 85vh; display: grid;

            grid-template-columns: 250px 1fr 250px; gap: 15px; padding: 20px;

            border: 2px solid var(--neon-blue); background: var(--panel-bg);

            box-shadow: 0 0 25px rgba(0, 242, 255, 0.2); position: relative;

        }

       

        .dashboard::before {

            content: " "; display: block; position: absolute;

            top: 0; left: 0; bottom: 0; right: 0;

            background: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), linear-gradient(90deg, rgba(255, 0, 0, 0.03), rgba(0, 255, 0, 0.01), rgba(0, 0, 255, 0.03));

            z-index: 10; background-size: 100% 2px, 3px 100%; pointer-events: none;

        }



        .side-panel { display: flex; flex-direction: column; gap: 15px; }

        .panel-card { border: 1px solid rgba(0, 242, 255, 0.3); padding: 15px; display: flex; flex-direction: column; justify-content: center; align-items: center; background: rgba(0, 0, 0, 0.3); position: relative; }

        .main-panel { display: flex; flex-direction: column; gap: 15px; }

        .graph-container { flex-grow: 1; border: 1px solid rgba(0, 242, 255, 0.3); position: relative; overflow: hidden; background-image: linear-gradient(rgba(0, 242, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 242, 255, 0.1) 1px, transparent 1px); background-size: 40px 40px; }

        canvas { width: 100%; height: 100%; display: block; }



        h2 { margin: 0 0 10px 0; font-size: 1.1rem; letter-spacing: 2px; border-bottom: 1px dashed var(--neon-blue); padding-bottom: 5px; width: 100%; }

        .label { font-size: 0.8rem; letter-spacing: 1px; opacity: 0.8; text-transform: uppercase; }

        .value { font-size: 3rem; font-weight: bold; text-shadow: 0 0 10px var(--neon-blue); }

        .unit { font-size: 1.2rem; vertical-align: super; opacity: 0.8; }

        .status-bar { margin-top: 10px; padding: 5px 10px; border: 1px solid var(--neon-blue); font-size: 0.9rem; transition: 0.3s; width: 80%; text-align: center; }

       

        .footer { position: absolute; bottom: 10px; left: 20px; right: 20px; display: flex; justify-content: space-between; font-size: 0.7rem; opacity: 0.7; border-top: 1px solid var(--neon-blue); padding-top: 5px; }

       

        .critical { --neon-blue: #ff2a2a; color: var(--neon-blue); border-color: var(--neon-blue); animation: pulse 0.8s infinite alternate; }

        .warning { --neon-blue: #ffaa00; color: var(--neon-blue); border-color: var(--neon-blue); }

        @keyframes pulse { from { box-shadow: 0 0 10px var(--neon-blue); } to { box-shadow: 0 0 30px var(--neon-blue); } }



        @media (max-width: 900px) { .dashboard { grid-template-columns: 1fr; grid-template-rows: auto auto auto; height: auto; } .side-panel { flex-direction: row; } .panel-card { flex: 1; } }

        @media (max-width: 600px) { .side-panel { flex-direction: column; } }

    </style>

</head>

<body>

    <div class="dashboard" id="main-dash">

        <div class="side-panel">

            <div class="panel-card">

                <h2>DADOS DO SISTEMA</h2>

                <div style="font-size: 0.7rem; text-align: left; width: 100%; opacity: 0.7;">

                    <p>> SENSOR: DS18B20</p>

                    <p>> PINO: GPIO 4</p>

                    <p>> STATUS: ATIVO</p>

                </div>

                <div class="status-bar" style="margin-top: auto;">ONLINE</div>

            </div>

            <div class="panel-card" style="height: 150px; justify-content: flex-end; gap: 5px;">

                 <div style="display: flex; gap: 5px; height: 100%; align-items: flex-end;">

                    <div style="width: 10px; height: 30%; background: var(--neon-blue); opacity: 0.5;"></div>

                    <div style="width: 10px; height: 60%; background: var(--neon-blue); opacity: 0.7;"></div>

                    <div style="width: 10px; height: 45%; background: var(--neon-blue); opacity: 0.6;"></div>

                    <div style="width: 10px; height: 80%; background: var(--neon-blue);"></div>

                    <div style="width: 10px; height: 50%; background: var(--neon-blue); opacity: 0.6;"></div>

                 </div>

                 <div class="label">CARGA DA CPU</div>

            </div>

        </div>



        <div class="main-panel">

            <div class="panel-card" style="flex-direction: row; justify-content: space-around;">

                <div>

                    <div class="label">TEMPERATURA REAL</div>

                    <div><span id="temp-val" class="value">--.-</span><span class="unit">°C</span></div>

                </div>

                <div>

                     <div class="label">STATUS DO MOTOR</div>

                     <div id="status-badge" class="status-bar">CONECTANDO...</div>

                </div>

            </div>

            <div class="graph-container">

                <canvas id="chart"></canvas>

            </div>

        </div>



        <div class="side-panel">

            <div class="panel-card">

                <h2>ESTATÍSTICAS</h2>

                <div style="display: flex; flex-direction: column; gap: 10px; width: 100%;">

                    <div style="display: flex; justify-content: space-between;"><span class="label">PICO:</span> <span id="peak-val">--.-</span></div>

                    <div style="display: flex; justify-content: space-between;"><span class="label">MÉDIA:</span> <span id="avg-val">--.-</span></div>

                </div>

            </div>

            <div class="panel-card">

                <div style="width: 80px; height: 80px; border: 5px solid var(--neon-blue); border-radius: 50%; border-top-color: transparent; transform: rotate(45deg); display: flex; justify-content: center; align-items: center;">

                    <span style="transform: rotate(-45deg); font-size: 1.2rem; font-weight: bold;">100%</span>

                </div>

                <div class="label" style="margin-top: 10px;">CONEXÃO</div>

            </div>

        </div>

       

        <div class="footer">

            <span>ID DO SISTEMA: ESP32-MOTOR-V2</span>

            <span>FLUXO DE DADOS: REAL (DS18B20)</span>

            <span>PORTA LÓGICA: 80</span>

        </div>

    </div>



<script>

    const canvas = document.getElementById('chart');

    const ctx = canvas.getContext('2d');

    let dataPoints = new Array(60).fill(0);

    let peakTemp = 0;



    function resize() { canvas.width = canvas.parentElement.clientWidth; canvas.height = canvas.parentElement.clientHeight; }

    window.addEventListener('resize', resize); resize();



    async function fetchData() {

        try {

            const response = await fetch('/api/data');

            const data = await response.json();

            updateUI(data.temperature, data.status);

        } catch (e) { console.error("Falha na conexão com o ESP32", e); }

    }



    function updateUI(temp, statusMsg) {

        document.getElementById('temp-val').innerText = temp.toFixed(1);

        const badge = document.getElementById('status-badge');

        badge.innerText = statusMsg;



        const dash = document.getElementById('main-dash');

        if (temp > 95) {

            dash.style.setProperty('--neon-blue', '#ff2a2a');

            badge.classList.add('critical'); badge.classList.remove('warning');

        } else if (temp > 85) {

            dash.style.setProperty('--neon-blue', '#ffaa00');

            badge.classList.add('warning'); badge.classList.remove('critical');

        } else {

            dash.style.setProperty('--neon-blue', '#00f2ff');

            badge.classList.remove('critical'); badge.classList.remove('warning');

        }



        if(temp > peakTemp) peakTemp = temp;

        document.getElementById('peak-val').innerText = peakTemp.toFixed(1) + "°C";

        const avg = dataPoints.reduce((a, b) => a + b, 0) / dataPoints.length;

        document.getElementById('avg-val').innerText = avg.toFixed(1) + "°C";



        dataPoints.push(temp); dataPoints.shift(); drawGraph();

    }



    function drawGraph() {

        const w = canvas.width; const h = canvas.height;

        ctx.clearRect(0, 0, w, h);



        ctx.beginPath(); ctx.lineWidth = 3;

        ctx.strokeStyle = getComputedStyle(document.body).getPropertyValue('--neon-blue');

        ctx.shadowBlur = 15; ctx.shadowColor = ctx.strokeStyle;



        const step = w / (dataPoints.length - 1);

        const maxTempScale = 120; // Teto do gráfico: 120°C



        for (let i = 0; i < dataPoints.length; i++) {

            let y = h - (dataPoints[i] / maxTempScale) * h;

            if (i === 0) ctx.moveTo(0, y);

            else ctx.lineTo(i * step, y);

        }

        ctx.stroke();

       

        ctx.lineTo(w, h); ctx.lineTo(0, h); ctx.closePath();

        ctx.fillStyle = ctx.strokeStyle.replace(')', ', 0.1)').replace('rgb', 'rgba');

        ctx.fill();

    }



    // Como é um sensor real, pedimos a temperatura a cada 1 segundo (1000ms)

    setInterval(fetchData, 1000);

</script>

</body>

</html>

)rawliteral";



void setup() {

    Serial.begin(115200);



    // Inicia o sensor real

    sensorTemp.begin();



    // Conecta no Wi-Fi

    WiFi.mode(WIFI_STA);

    WiFi.begin(ssid, password);

    Serial.print("\nConectando ao Wi-Fi");

    while (WiFi.status() != WL_CONNECTED) {

        delay(500);

        Serial.print(".");

    }

    Serial.println("\nCONECTADO!");

    Serial.print("Acesse: http://");

    Serial.println(WiFi.localIP());



    // Rotas do servidor

    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){

        request->send_P(200, "text/html", index_html);

    });



    server.on("/api/data", HTTP_GET, [](AsyncWebServerRequest *request){

        StaticJsonDocument<200> doc;

        doc["temperature"] = currentTemp;

        doc["status"] = systemStatus;

       

        String response;

        serializeJson(doc, response);

        request->send(200, "application/json", response);

    });



    server.begin();

}



void loop() {

    // Lê o sensor físico a cada 1 segundo

    if (millis() - lastUpdate > 1000) {

        sensorTemp.requestTemperatures();

        float tempLida = sensorTemp.getTempCByIndex(0);



        // Se o fio do sensor não estiver solto...

        if (tempLida != DEVICE_DISCONNECTED_C) {

            currentTemp = tempLida;

           

            // Define os alertas baseados na temperatura real

            if (currentTemp > 95) systemStatus = "PERIGO: CRÍTICO";

            else if (currentTemp > 85) systemStatus = "ALERTA: CARGA ALTA";

            else systemStatus = "SISTEMA NORMAL";

        } else {

            // Se der problema no resistor ou no fio

            systemStatus = "ERRO: SENSOR OFF";

        }

       

        lastUpdate = millis();

    }

}